package com.eatallme.aetheris.items;

import net.minecraft.item.Item;

public class FusionCatalystItem extends Item {
    public FusionCatalystItem(Properties properties) {
        super(properties);
    }
}
